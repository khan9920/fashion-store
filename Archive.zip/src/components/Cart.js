import React, { Component } from 'react'

export default class Cart extends Component {
    render() {
        return (
            <div>
                <h3>Hello from cart</h3>
            </div>
        )
    }
}
