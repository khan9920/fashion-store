// delete button style
export default {
    row: {
        padding: '20px 0'
    },
    brand: {
        fontSize: '30px',
        fontWeight: '600',
        textDecoration: "none",
        color: '#000'
    },
    navListUl: {
        padding: "0",
        textAlign: "right",
        position: "relative",
        top: "10px"
    },
    linkList: {
        display: "inline-block",
        textDecoration: "none",
        marginRight: "50px",
    },
    linkListIcon: {
        fontSize: "22px",
        position: "relative",
        top: "6px",
        marginRight: "5px"
    },
    linktListA: {
        color: '#000',
    }
}
