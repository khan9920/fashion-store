import React, { Component } from 'react'

export default class _AddProduct extends Component {
    constructor(props) {
        super(props);
        this.initialState = {
            file: null,
            _id: '',
            name: '',
            productImage: '',
            price: '',
            category: '',
            quantity: '',
            description: '',
            discount: '',
        }

        if (props.product) {
            this.state = props.product;
        } else {
            this.state = this.initialState;
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleFile = this.handleFile.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event) {
        const name = event.target.name;
        const value = event.target.value;
        this.setState({
            [name]: value
        });
    }

    handleFile(event) {
        this.setState({
            productImage: event.target.files[0],
            file: URL.createObjectURL(event.target.files[0])
        });
    }

    handleSubmit(event) {
        event.preventDefault();
        this.props.onFormSubmit(this.state);
        this.setState(this.initialState);

    }
    render() {

        let pageTitle, image;
        console.log(this.state.file)
        if (this.state._id) {
            pageTitle = <h2>Edit Product</h2>
            if (this.state.file) {
                image = <img className="productImage1" alt='productI' src={this.state.file}></img>
            } else {
                image = <img className="productImage1" alt='productI' src={'http://localhost:4000/' + this.state.productImage}></img>
            }
        } else {
            pageTitle = <h2>Add Product</h2>
        }

        if (this.state._id) {
            return (
                <div>
                    <p>EDIT PRODUCT</p>
                    <form onSubmit={this.handleSubmit}>
                        <div className="row">
                            <input type="hidden" name="id" value={this.state._id} />
                            <div className="col-md-3">
                                <label>Name</label>
                                <input type="text" placeholder="eg: Shirt" name="name" value={this.state.name} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Price</label>
                                <input type="text" placeholder="eg: 1000" name="price" value={this.state.price} onChange={this.handleChange} />
                            </div>
                            {/* <div className="col-md-3">
                            <label>Discount</label>
                            <input type="text" placeholder="eg: 10" name="discount" value={this.state.discount} onChange={this.handleChange} />
                        </div> */}
                            <div className="col-md-3">
                                <label>Qauntity</label>
                                <input type="text" placeholder="eg: 10" name="qauntity" value={this.state.qauntity} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Descriptoin</label>
                                <input type="text" placeholder="eg: This is a shirt" name="descriptoin" value={this.state.descriptoin} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Category</label>
                                <input type="text" placeholder="category" name="category" value={this.state.category} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Image</label>
                                <input type="file" placeholder="eg: 1000" name="productImage" onChange={this.handleFile} />
                            </div>
                            <button type="submit">SAVE</button>
                        </div>
                    </form>
                </div>
            )
        } else {
            return (
                <div>
                    <p>ADD PRODUCT</p>
                    <form onSubmit={this.handleSubmit}>
                        <div className="row">
                            <input type="hidden" name="id" value={this.state._id} />
                            <div className="col-md-3">
                                <label>Name</label>
                                <input type="text" placeholder="eg: Shirt" name="name" value={this.state.name} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Price</label>
                                <input type="text" placeholder="eg: 1000" name="price" value={this.state.price} onChange={this.handleChange} />
                            </div>
                            {/* <div className="col-md-3">
                            <label>Discount</label>
                            <input type="text" placeholder="eg: 10" name="discount" value={this.state.discount} onChange={this.handleChange} />
                        </div> */}
                            <div className="col-md-3">
                                <label>Qauntity</label>
                                <input type="text" placeholder="eg: 10" name="qauntity" value={this.state.qauntity} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Descriptoin</label>
                                <input type="text" placeholder="eg: This is a shirt" name="descriptoin" value={this.state.descriptoin} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Category</label>
                                <input type="text" placeholder="category" name="category" value={this.state.category} onChange={this.handleChange} />
                            </div>
                            <div className="col-md-3">
                                <label>Image</label>
                                <input type="file" placeholder="eg: 1000" name="productImage" onChange={this.handleFile} />
                            </div>
                            <button type="submit">SAVE</button>
                        </div>
                    </form>
                </div>
            )
        }
    }
}
