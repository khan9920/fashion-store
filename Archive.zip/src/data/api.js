export const API = {
  URL: '//localhost:4000/api/v1/'
};
